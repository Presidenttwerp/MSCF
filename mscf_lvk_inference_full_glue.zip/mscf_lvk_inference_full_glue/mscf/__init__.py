# MSCF inference helpers
